package com.epam.mentoring.droplets;

import java.util.Map;

/**
 * Created by oracle on 7/1/19.
 */
public class WeekDaysMapper {
    private Map<String, String> weekDaysMap;//LinkedHashMap

    public WeekDaysMapper() {
    }

    public Map<String, String> getWeekDaysMap() {
        return weekDaysMap;
    }

    public void setWeekDaysMap(Map<String, String> weekDaysMap) {
        this.weekDaysMap = weekDaysMap;
    }
}
