package com.epam.mentoring.droplets;

import java.util.List;

/**
 * Created by oracle on 6/25/19.
 */
public class WeekDays {
    private List<String> days;

    public List<String> getDays() {
        return days;
    }

    public void setDays(List<String> days) {
        this.days = days;
    }
}
