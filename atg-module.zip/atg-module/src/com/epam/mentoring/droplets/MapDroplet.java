package com.epam.mentoring.droplets;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.Map;

/**
 * Created by oracle on 7/1/19.
 */
public class MapDroplet extends DynamoServlet {
    private WeekDaysMapper mapper;
    //TODO add map and set map int the property file from WeekDaysMapper

    @Override
    public void service(DynamoHttpServletRequest req, DynamoHttpServletResponse res) throws ServletException, IOException {
        String passedDay = req.getParameter("day");
        if (!mapper.getWeekDaysMap().containsKey(passedDay)) {
            for (Map.Entry<String, String> entry : mapper.getWeekDaysMap().entrySet()) {
                req.setParameter("dayName", entry.getKey());
                req.setParameter("dayType", entry.getValue());
                req.serviceParameter("showDayFromMap", req, res);
            }
        } else {
            req.setParameter("dayType", mapper.getWeekDaysMap().get(passedDay));
            req.serviceParameter("showDayByInput", req, res);
        }
    }

    public WeekDaysMapper getMapper() {
        return mapper;
    }

    public void setMapper(WeekDaysMapper mapper) {
        this.mapper = mapper;
    }
}
