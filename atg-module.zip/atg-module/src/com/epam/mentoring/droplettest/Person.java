package com.epam.mentoring.droplettest;

/**
 * Created by oracle on 6/27/19.
 */
public class Person {
    private int age;

    public Person() {
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
