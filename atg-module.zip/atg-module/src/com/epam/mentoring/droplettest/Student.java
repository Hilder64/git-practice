package com.epam.mentoring.droplettest;

import java.util.List;

/**
 * Created by oracle on 6/27/19.
 */
public class Student {
    private List<String> subjects;

    public Student() {
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }
}
