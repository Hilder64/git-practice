package com.epam.mentoring.droplettest;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Created by oracle on 6/27/19.
 */
public class Counter extends DynamoServlet {
    public Counter() {
    }

    public void service(DynamoHttpServletRequest request,
                        DynamoHttpServletResponse response)
            throws ServletException, IOException {
        int maxcount = 0;
        Object maxcountval = request.getObjectParameter("maxcount");
        if (maxcountval instanceof Integer) {
            maxcount = ((Integer) maxcountval).intValue();
        }

        for (int i = 0; i < maxcount; i++) {
            request.setParameter("number", new Integer(i));
            request.serviceParameter("lineformat", request, response);
        }
    }
}