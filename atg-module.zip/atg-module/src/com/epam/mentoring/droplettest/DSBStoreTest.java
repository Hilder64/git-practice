package com.epam.mentoring.droplettest;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import java.io.IOException;

/**
 * Created by oracle on 6/27/19.
 */
public class DSBStoreTest extends DynamoServlet {

    public DSBStoreTest() {
    }

    @Override
    public void service(DynamoHttpServletRequest req, DynamoHttpServletResponse res) throws ServletException, IOException {
        String storename = req.getParameter("storename");
        if (storename == null) storename = "No-Name's";

        ServletOutputStream out = res.getOutputStream();
        out.println("<h1>Welcome to " + storename + "</h1>");
    }
}
