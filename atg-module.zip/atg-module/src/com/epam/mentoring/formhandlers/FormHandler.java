package com.epam.mentoring.formhandlers;

import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import com.epam.mentoring.formhandlers.validation.ValidationProcessor;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Created by oracle on 7/4/19.
 */
public class FormHandler extends GenericFormHandler {
    private String successURL;
    private String failureURL;
    private OrderDetails orderDetails;
    private OrderDetailsDTO orderDetailsDTO;
    private ValidationProcessor validationProcessor;

    public boolean handleValidate(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
            throws java.io.IOException, javax.servlet.ServletException {
        validateParams();
        return checkFormRedirect(successURL, failureURL, pRequest, pResponse);
    }

    private void validateParams() {
        Map<String, List<String>> errorMap = validationProcessor.validate(orderDetailsDTO);
        for (Map.Entry<String, List<String>> entry : errorMap.entrySet()) {
            for (String errorMessage : entry.getValue()) {
                addFormException(new DropletException(errorMessage));
            }
        }
    }

    private void setOrderDetailsProperties() {
        orderDetails.setOrderId(orderDetailsDTO.getOrderId());
        orderDetails.setItemCount(orderDetailsDTO.getItemCount());
        orderDetails.setCustomerEmail(orderDetailsDTO.getCustomerEmail());
    }

    @Override
    public boolean checkFormRedirect(String pSuccessURL, String pFailureURL, DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        if (this.getFormError()) {
            if (StringUtils.isBlank(pFailureURL)) {
                return true;
            } else {
                this.redirectOrForward(pRequest, pResponse, pFailureURL);
                return false;
            }
        } else {
            setOrderDetailsProperties();
            if (StringUtils.isBlank(pSuccessURL)) {
                return true;
            } else {
                this.redirectOrForward(pRequest, pResponse, pSuccessURL);
                return false;
            }
        }
    }

    public String getSuccessURL() {
        return successURL;
    }

    public void setSuccessURL(String successURL) {
        this.successURL = successURL;
    }

    public String getFailureURL() {
        return failureURL;
    }

    public void setFailureURL(String failureURL) {
        this.failureURL = failureURL;
    }

    public OrderDetails getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(OrderDetails orderDetails) {
        this.orderDetails = orderDetails;
    }

    public OrderDetailsDTO getOrderDetailsDTO() {
        return orderDetailsDTO;
    }

    public void setOrderDetailsDTO(OrderDetailsDTO orderDetailsDTO) {
        this.orderDetailsDTO = orderDetailsDTO;
    }

    public ValidationProcessor getValidationProcessor() {
        return validationProcessor;
    }

    public void setValidationProcessor(ValidationProcessor validationProcessor) {
        this.validationProcessor = validationProcessor;
    }
}
