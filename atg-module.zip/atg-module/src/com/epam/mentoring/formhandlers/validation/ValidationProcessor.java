package com.epam.mentoring.formhandlers.validation;

import atg.nucleus.ServiceMap;
import com.epam.mentoring.formhandlers.OrderDetailsDTO;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by oracle on 7/4/19.
 */
public class ValidationProcessor {
    private ServiceMap<Validator> validatorServiceMap;

    public Map<String, List<String>> validate(OrderDetailsDTO orderDetailsDTO) {
        Map<String, List<String>> errorMap = new HashMap<>();
        Field[] fields = orderDetailsDTO.getClass().getDeclaredFields();
        for (Field f : fields) {
            try {
                String methodName = "get" + f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1);
                String fieldValue = (String) orderDetailsDTO.getClass().getDeclaredMethod(methodName).invoke(orderDetailsDTO);
                Validator validator = validatorServiceMap.get(f.getName());
                if (validator != null) {
                    List<String> errorMessages = validator.validate(fieldValue);
                    if (errorMessages != null && !errorMessages.isEmpty()) {
                        errorMap.put(f.getName(), errorMessages);
                    }
                }
            } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
        return errorMap;
    }

    public ServiceMap<Validator> getValidatorServiceMap() {
        return validatorServiceMap;
    }

    public void setValidatorServiceMap(ServiceMap<Validator> validatorServiceMap) {
        this.validatorServiceMap = validatorServiceMap;
    }
}
