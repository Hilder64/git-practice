package com.epam.mentoring.formhandlers.validation;

import java.util.List;

/**
 * Created by oracle on 7/4/19.
 */
public interface Validator {
    List<String> validate(String value);
}
