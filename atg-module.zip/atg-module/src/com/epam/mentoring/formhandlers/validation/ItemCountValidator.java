package com.epam.mentoring.formhandlers.validation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by oracle on 7/4/19.
 */
public class ItemCountValidator implements Validator {
    private String itemCountRegex;
    private Integer digitsCount;

    @Override
    public List<String> validate(String value) {
        List<String> errorMessages = new ArrayList<>();
        if (value.isEmpty()) {
            errorMessages.add("Item count is required");
        }
        if (!value.matches(itemCountRegex)) {
            errorMessages.add("Item count must consist of numbers only");
        }
        if (value.length() < digitsCount) {
            errorMessages.add("Item count must have at least 2 number");
        }
        return errorMessages;
    }

    public String getItemCountRegex() {
        return itemCountRegex;
    }

    public void setItemCountRegex(String itemCountRegex) {
        this.itemCountRegex = itemCountRegex;
    }

    public Integer getDigitsCount() {
        return digitsCount;
    }

    public void setDigitsCount(Integer digitsCount) {
        this.digitsCount = digitsCount;
    }
}
