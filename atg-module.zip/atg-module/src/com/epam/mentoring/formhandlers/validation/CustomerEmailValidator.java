package com.epam.mentoring.formhandlers.validation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by oracle on 7/4/19.
 */
public class CustomerEmailValidator implements Validator {
    private String customerEmailRegex;

    @Override
    public List<String> validate(String value) {
        List<String> errorMessages = new ArrayList<>();
        if (value.isEmpty()) {
            errorMessages.add("Email address is required");
        }
        if (!value.matches(customerEmailRegex)) {
            errorMessages.add("This is not a valid email address");
        }
        return errorMessages;
    }

    public String getCustomerEmailRegex() {
        return customerEmailRegex;
    }

    public void setCustomerEmailRegex(String customerEmailRegex) {
        this.customerEmailRegex = customerEmailRegex;
    }
}
