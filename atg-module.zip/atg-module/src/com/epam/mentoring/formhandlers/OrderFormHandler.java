package com.epam.mentoring.formhandlers;

import atg.commerce.order.Order;
import atg.projects.store.mobile.order.purchase.MobileStoreCartFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Created by oracle on 7/15/19.
 */
public class OrderFormHandler extends MobileStoreCartFormHandler {
    private OrderDetails orderDetails;

    @Override
    protected void updateOrder(Order pOrder, String pMsgId, DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
            throws ServletException, IOException {
        super.updateOrder(pOrder, pMsgId, pRequest, pResponse);

        String orderID = getOrder().getId();
        String itemCount = Long.toString(getOrder().getTotalCommerceItemCount());
        String customerEmail = getProfile().getItemDisplayName();

        orderDetails.setOrderId(orderID);
        orderDetails.setItemCount(itemCount);
        orderDetails.setCustomerEmail(customerEmail);
    }

    public OrderDetails getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(OrderDetails orderDetails) {
        this.orderDetails = orderDetails;
    }
}